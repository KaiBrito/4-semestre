INSERT INTO Pagamento (valor, idPedido)
VALUES (25.00, 7);

INSERT INTO Dinheiro (idPagamento, troco)
VALUES (11, 2.50);

INSERT INTO Pedido (cpf)
VALUES ('12345678901');

INSERT INTO Pedido (cpf)
VALUES ('45678901234');

INSERT INTO Restaurante (nome, endereco, telefone)
VALUES ('Restaurante BK', '486 Avenida Do Horizonte, Cidade Bataguassu', '(456) 789-1230');